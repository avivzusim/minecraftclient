package clientname;


import java.awt.Color;

import org.lwjgl.input.Mouse;

import clientname.event.EventManager;
import clientname.event.EventTarget;
import clientname.event.impl.ClientTickEvent;
import clientname.gui.SplashProgress;
import clientname.gui.gui.GUIToggle;
import clientname.gui.hud.HUDManager;
import clientname.mods.ModInstances;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class Client {
	
	private static final Client INSTANCE = new Client();
	public static final Client getInstance() {
		
		
		return INSTANCE;
		
		
	}
	
	public HUDManager getHudManager() {
		return hudManager;
	}
	

	public static boolean LogoButtons = false;
	
	public static boolean ChromaText = false;
	
	public static boolean LeftHand = false;
	
	public static boolean WidePlayer = false;
	
	public static boolean DynamicFOV = false;
	
	public static boolean  CosmeticGhostWings = false;
	
	public static boolean CosmeticCap = false;
	
	
	
	//TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7TriHard 7TriHard 7 TriHard 7 TriHard 7 TriHard 7 
	
	public static int ConfigScreenColor = 0xFF00AA00;
	
	public static Color SplashColor = new Color(0, 170, 0);
	
	public static int guiToggleClientName = 50;
	
	public static String ClientName = "Emblem Client";
	
	public static String KlammerFarbe = "§f";
	
	public static String ModFarbe = "§2";
	
	public static int ButtonHover = 43520;
	
	public static String DiscordID = "829694095320547359";
	
	//TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7 TriHard 7TriHard 7TriHard 7 TriHard 7 TriHard 7 TriHard 7
	
	
	public static boolean CosmeticHat;
	public static boolean CosmeticWitchHat;
	public static boolean DiamondHead;
	public static boolean ChatBackground;
	public static boolean BetterAnimations;
	public static boolean ItemPhysics;
	public static boolean ToggleSprint;
	public static boolean CosmeticWings;
	public static boolean CosmeticHalo;
	public static boolean CosmeticCape;
	public static boolean ModBiom= true;
	public static boolean ModFPS= true;
	public static boolean ModPing= true;
	public static boolean ModPotionstatus= true;
	public static boolean ModTimeShow= true;
	public static boolean ModPosition= true;
	public static boolean ModArmorStatus= true;
	public static boolean ModKeystrokes= true;
	
	public static String Background = "background.png";
	
	public static String Cape = "cape.png";
	
	public static String SplashScreen = "splash.png";
	 
	public static String Logo = "tollerzitronens-01.jpeg";
	
	private DiscordRP discordRP = new DiscordRP();
	
	private HUDManager hudManager;
	
	int scrollTotal = 4;
	
	private static boolean prevIsKeyDown = false;
	
	private static float savedFOV = 0;
	
	public void init() {
		SplashProgress.setProgress(1, Client.ClientName + " - Discord Initialisation");
		FileManager.init();
		discordRP.start();
		EventManager.register(this);
		
	}
	
	public void start() {
		hudManager = HUDManager.getInstance();
		ModInstances.register(hudManager);
	}
	
	public void shutdown() {
		discordRP.shutdown();
	}
	
	public DiscordRP getDiscordRP() {
		return discordRP;
	}
	
	@EventTarget
	public void onTick(ClientTickEvent e) {
		if(Minecraft.getMinecraft().gameSettings.CLIENT_GUI_MOD_POS.isPressed()) {
			hudManager.openConfigScreen();
		}
		if(Minecraft.getMinecraft().gameSettings.CLIENT_GUI_MOD_SETTINGS.isPressed()) {
			Minecraft.getMinecraft().displayGuiScreen(new GUIToggle(null));
		}
		 boolean isKeyDown = Minecraft.getMinecraft().gameSettings.ZOOM.isKeyDown();
		    if(prevIsKeyDown != isKeyDown) {
		        if(isKeyDown) {
		            savedFOV = Minecraft.getMinecraft().gameSettings.fovSetting;
		            Minecraft.getMinecraft().gameSettings.fovSetting = 30;
		            Minecraft.getMinecraft().gameSettings.smoothCamera = true; 
		        } else {
		            Minecraft.getMinecraft().gameSettings.fovSetting = savedFOV;
		            Minecraft.getMinecraft().gameSettings.smoothCamera = false;
		        }
		    }
		    prevIsKeyDown = isKeyDown;
		}
	



}
		

