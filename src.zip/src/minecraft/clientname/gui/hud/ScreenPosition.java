package clientname.gui.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class ScreenPosition {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private int x, y;

    public ScreenPosition(double x, double y) {
        setRelative(x, y);
    }

    public ScreenPosition(int x, int y) {
        setAbsolute(x, y);
    }

    public static ScreenPosition fromRelativePosition(double x, double y) {
        return new ScreenPosition(x, y);
    }

    public static ScreenPosition fromAbsolute(int x, int y) {
        return new ScreenPosition(x, y);
    }

    public int getAbsoluteX() {
		ScreenResolution resolution = new ScreenResolution(mc);
        return x;
    }

    public int getAbsoluteY() {
		ScreenResolution resolution = new ScreenResolution(mc);
        return y;
    }

    public double getRelativeX() {
		ScreenResolution res =  new ScreenResolution(mc);
		return (int) (x / res.getScaledWidth_double());
    }

    public double getRelativeY() {
		ScreenResolution res =  new ScreenResolution(mc);
		return (int) (y / res.getScaledHeight_double());
    }

    public void setAbsolute(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setRelative(double x, double y) {
		ScreenResolution res = new ScreenResolution(mc);
		
		this.x =  (int) (x / res.getScaledWidth());
		this.y =  (int) (y / res.getScaledHeight());
		System.err.println(x);
		System.out.println(y);
	}
	
}
