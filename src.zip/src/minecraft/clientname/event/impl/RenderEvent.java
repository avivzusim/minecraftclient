package clientname.event.impl;

import clientname.event.Event;

public class RenderEvent extends Event {

}
