package clientname;


import net.minecraft.client.gui.GuiButton;

public class GuiButtonScope extends GuiButton{

	public GuiButtonScope(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
		super(buttonId, x, y, widthIn, heightIn, buttonText);
	}

}
