package clientname.mods;

import clientname.Client;
import clientname.event.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class Mod {

    private boolean isEnabled = true;
    
    protected final Minecraft mc;
    protected static FontRenderer font;
    protected final Client client;
    
    public Mod() {
        this.mc = Minecraft.getMinecraft();
        this.font = this.mc.fontRendererObj;
        this.client = Client.getInstance();
        
        setEnabled(isEnabled);
    }

    private void setEnabled(boolean isEnabled) {    
        this.isEnabled = isEnabled;
        
        if(isEnabled) {
            EventManager.register(this);
        }
        else {
            EventManager.unregister(this);
        }
                    
    }
    
    public boolean isEnabled() {
        return isEnabled;
    }
    
}