package clientname.mods.impl;

import clientname.ChromaText;
import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.GameSettings;

public class FovMod extends ModDraggable {
	
	private static float savedFOV = 0;
	
	

	 public int getWidth()
	    {
		 return font.getStringWidth("[DynamicFov On]");
	    }

	    @Override
	    public int getHeight()
	    {
	    	return font.FONT_HEIGHT;
	    }
	    


		@Override
		public void render(ScreenPosition pos) {
			if(Client.DynamicFOV) {
				if(!Client.ChromaText) {
			 font.drawStringWithShadow(Client.KlammerFarbe + "[" + Client.ModFarbe + "DynamicFov On" + Client.KlammerFarbe + "]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
				} else {
					ChromaText.drawChromaString("DynamicFov On", pos.getAbsoluteX(), pos.getAbsoluteY(), true);
				}
			savedFOV = Minecraft.getMinecraft().gameSettings.fovSetting;
			if(mc.thePlayer.isSprinting()) {
				Minecraft.getMinecraft().gameSettings.fovSetting = savedFOV;
				}
			else if(mc.thePlayer.isPotionActive(1)) {
				Minecraft.getMinecraft().gameSettings.fovSetting = savedFOV;
			}
			else if(mc.thePlayer.capabilities.isFlying) {
				Minecraft.getMinecraft().gameSettings.fovSetting = savedFOV;
		}
		}
		}
	}
				
			