package clientname;

import net.minecraft.client.gui.GuiButton;

import java.awt.Color;
import java.awt.Font;

import org.lwjgl.opengl.GL11;




import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class GuiLogoButton extends GuiButtonScope{

	
	ScaledResolution scaledResolution;
	
	ResourceLocation location;
	boolean isHead;
	
	public GuiLogoButton(int buttonId, ScaledResolution scaledResolution,int x, int y, int widthIn, int heightIn, ResourceLocation location,boolean isHead) {
		super(buttonId, x, y, widthIn, heightIn, "");
		this.scaledResolution = scaledResolution;
		this.location = location;
		this.isHead = isHead;
	}
	
	@Override
	public void drawButton(Minecraft mc, int mouseX, int mouseY) {
		if(this.visible) {
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            boolean flag = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
            int i = 106;

            if (flag)
            {
                i += this.height;
            }
           
            mc.getTextureManager().bindTexture(location);
            if (mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height) {
                if(isHead) {
                    GL11.glPushMatrix();
                    GL11.glScissor(0, (int) (575 / scaledResolution.getScale()) * scaledResolution.getScaleFactor(),(int) (62 / scaledResolution.getScale()) * scaledResolution.getScaleFactor() +2, 100);
                	GL11.glEnable(GL11.GL_SCISSOR_TEST);
                }
             	Gui.drawScaledCustomSizeModalRect(xPosition - 10 , yPosition - 10, - 5,  - 5, width +10, height +10, width +10,height +10, width + 10 , height  +10);
            }else {
                if(isHead) {
                    GL11.glPushMatrix();
                	GL11.glScissor(0, (int) (580 / scaledResolution.getScale()) * scaledResolution.getScaleFactor(),(int) (60 / scaledResolution.getScale()) * scaledResolution.getScaleFactor() +2, 100);
                	GL11.glEnable(GL11.GL_SCISSOR_TEST);
                }
            	Gui.drawScaledCustomSizeModalRect(xPosition, yPosition, 0, 0, width, height, width,height, width, height);
            }
            if(isHead) {
                GL11.glDisable(GL11.GL_SCISSOR_TEST);
                GL11.glPopMatrix();
            }
           // this.drawTexturedModalRect(xPosition, yPosition, 0,0, width, height);
		}
	}
	

}
