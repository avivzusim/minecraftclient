package clientname.cosmetics;


import java.awt.Color;

import clientname.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class CosmeticCap extends Cosmetic{

    ModelRenderer Cap1;
    ModelRenderer Cap2;
    ModelRenderer Cap3;
    ModelRenderer Cap4;
    ModelRenderer Cap5;
    ModelRenderer Cap6;
    ModelRenderer cap7;
	
	public CosmeticCap(RenderPlayer player) {
		super(player);
		 textureWidth = 64;
		    textureHeight = 32;
		    
		      Cap1 = new ModelRenderer(this, 0, 0);
		      Cap1.addBox(0F, 0F, 0F, 8, 1, 11);
		      Cap1.setRotationPoint(-4F, -9F, -7F);
		      Cap1.setTextureSize(64, 32);
		      Cap1.mirror = true;
		      Cap2 = new ModelRenderer(this, 0, 0);
		      Cap2.addBox(0F, 0F, 0F, 8, 1, 1);
		      Cap2.setRotationPoint(-4F, -9F, -8F);
		      Cap2.setTextureSize(64, 32);
		      Cap2.mirror = true;
		      Cap3 = new ModelRenderer(this, 0, 0);
		      Cap3.addBox(0F, 0F, 0F, 8, 3, 1);
		      Cap3.setRotationPoint(-4F, -12F, -4F);
		      Cap3.setTextureSize(64, 32);
		      Cap3.mirror = true;
		      Cap4 = new ModelRenderer(this, 0, 0);
		      Cap4.addBox(0F, 0F, 0F, 8, 3, 1);
		      Cap4.setRotationPoint(-4F, -12F, 3F);
		      Cap4.setTextureSize(64, 32);
		      Cap4.mirror = true;
		      Cap5 = new ModelRenderer(this, 0, 0);
		      Cap5.addBox(0F, 0F, 0F, 1, 3, 6);
		      Cap5.setRotationPoint(-4F, -12F, -3F);
		      Cap5.setTextureSize(64, 32);
		      Cap5.mirror = true;
		      Cap6 = new ModelRenderer(this, 0, 0);
		      Cap6.addBox(0F, 0F, 0F, 1, 3, 6);
		      Cap6.setRotationPoint(3F, -12F, -3F);
		      Cap6.setTextureSize(64, 32);
		      Cap6.mirror = true;
		      cap7 = new ModelRenderer(this, 0, 0);
		      cap7.addBox(0F, 0F, 0F, 6, 1, 6);
		      cap7.setRotationPoint(-3F, -12F, -3F);
		      cap7.setTextureSize(64, 32);
		      cap7.mirror = true;
	}

	@Override
	public void render(AbstractClientPlayer player, float limbSwing, float limbSwingAmount, float partialTicks,
			float ageInTicks, float headYaw, float headPitch, float scale) {
		
if(Client.CosmeticCap) {
			GlStateManager.pushMatrix();
			float f = partialTicks;

	        float f1 = this.getFirstRotationX(player, f);
	        float f2 = this.getSecondRotationX(player, f);
			
			GlStateManager.color(1, 1, 1,1);
			setRotationAngles(limbSwing, limbSwingAmount, partialTicks, ageInTicks, headYaw, headPitch, player);
			Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation("cap.png"));
	        GlStateManager.rotate(f1, 0.0F, 1.0F, 0.0F);
	        GlStateManager.rotate(f2, 1.0F, 0.0F, 0.0F);
	    	GlStateManager.disableLighting();
	        
	        if(player.isSneaking()) {
	        	GlStateManager.translate(0,0.26, -0.047);
	        }

	        
		    Cap1.render(scale);
		    Cap2.render(scale);
		    Cap3.render(scale);
		    Cap4.render(scale);
		    Cap5.render(scale);
		    Cap6.render(scale);
		    cap7.render(scale);
		    GlStateManager.popMatrix();
}
	}
	
	
	 private float getFirstRotationX(AbstractClientPlayer Player, float partialTicks)
	    {
	        float f = this.interpolateRotation(Player.prevRenderYawOffset, Player.renderYawOffset, partialTicks);
	        float f1 = this.interpolateRotation(Player.prevRotationYawHead, Player.rotationYawHead, partialTicks);
	        float f2 = f1 - f;

	        if (Player.isRiding() && Player.ridingEntity instanceof EntityLivingBase)
	        {
	            EntityLivingBase entitylivingbase = (EntityLivingBase)Player.ridingEntity;
	            f = this.interpolateRotation(entitylivingbase.prevRenderYawOffset, entitylivingbase.renderYawOffset, partialTicks);
	            f2 = f1 - f;
	            float f3 = MathHelper.wrapAngleTo180_float(f2);

	            if (f3 < -85.0F)
	            {
	                f3 = -85.0F;
	            }

	            if (f3 >= 85.0F)
	            {
	                f3 = 85.0F;
	            }

	            f = f1 - f3;

	            if (f3 * f3 > 2500.0F)
	            {
	                float f4 = f + f3 * 0.2F;
	            }
	        }

	        return f2;
	    }

	    private float getSecondRotationX(AbstractClientPlayer Player, float partialTicks)
	    {
	        return Player.prevRotationPitch + (Player.rotationPitch - Player.prevRotationPitch) * partialTicks;
	    }
	    
	    private float interpolateRotation(float par1, float par2, float par3)
	    {
	        float f;

	        for (f = par2 - par1; f < -180.0F; f += 360.0F)
	        {
	            ;
	        }

	        while (f >= 180.0F)
	        {
	            f -= 360.0F;
	        }

	        return par1 + par3 * f;
	    }

	  public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity)
	  {
	    super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
	  }

	
}

