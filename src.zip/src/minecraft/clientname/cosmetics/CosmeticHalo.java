package clientname.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

import java.awt.Color;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;

import org.lwjgl.opengl.GL11;

import clientname.Client;
import clientname.cosmetics.util.CosmeticBase;
import clientname.cosmetics.util.CosmeticModelBase;
import net.minecraft.client.model.ModelBiped;





public class CosmeticHalo extends CosmeticBase {
  private final HaloRenderer haloModel;
  
  public CosmeticHalo(RenderPlayer renderPlayer) {
    super(renderPlayer);
    this.haloModel = new HaloRenderer(renderPlayer);
  }
  
  public void render(AbstractClientPlayer player, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {

	  GL11.glPushMatrix();
  	if(player.isSneaking()) {
    	GlStateManager.translate(0, 0.225, 0);
  	}
  	if(Client.CosmeticHalo) {
  		Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation("Halo.png"));
    	
  		GlStateManager.color(1F, 1, 1F);
  	
  
	  	 this.haloModel.render((Entity)player, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);	 
  	}
  	
      GL11.glPopMatrix();
    } 

  
  
  public class HaloRenderer extends CosmeticModelBase {
	  
	  	ModelRenderer head;
	    ModelRenderer body;
	    ModelRenderer rightarm;
	    ModelRenderer leftarm;
	    ModelRenderer rightleg;
	    ModelRenderer leftleg;
	    ModelRenderer Shape1;
	    ModelRenderer Shape2;
	    ModelRenderer Shape3;
	    ModelRenderer Shape4;

	    ModelRenderer Shape6;
	   
    
    public HaloRenderer(RenderPlayer player) {
      super(player);
      
      textureWidth = 64;
      textureHeight = 32;

      Shape1 = new ModelRenderer(this, 0, 0);
      Shape1.addBox(0F, 0F, 0F, 1, 1, 1);
      Shape1.setRotationPoint(0F, 0F, 0F);
      Shape1.setTextureSize(64, 32);
      Shape1.mirror = true;

      Shape2 = new ModelRenderer(this, 0, 0);
      Shape2.addBox(0F, 0F, 0F, 6, 1, 1);
      Shape2.setRotationPoint(-3F, -11F, -4F);
      Shape2.setTextureSize(64, 32);
      Shape2.mirror = true;

      Shape3 = new ModelRenderer(this, 0, 0);
      Shape3.addBox(0F, 0F, 0F, 1, 1, 6);
      Shape3.setRotationPoint(-4F, -11F, -3F);
      Shape3.setTextureSize(64, 32);
      Shape3.mirror = true;

      Shape4 = new ModelRenderer(this, 0, 0);
      Shape4.addBox(0F, 0F, 0F, 1, 1, 6);
      Shape4.setRotationPoint(3F, -11F, -3F);
      Shape4.setTextureSize(64, 32);
      Shape4.mirror = true;



      Shape6 = new ModelRenderer(this, 0, 0);
      Shape6.addBox(0F, 0F, 0F, 6, 1, 1);
      Shape6.setRotationPoint(-3F, -11F, 3F);
      Shape6.setTextureSize(64, 32);
      Shape6.mirror = true;

      



            
      
    
    }
    
    public void render(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch, float scale) {
    	if(entityIn.getName().equals(Minecraft.getMinecraft().getSession().getUsername())) {
    	GlStateManager.pushMatrix();


    	
    	float f1 = + ageInTicks / 100F;
    	float f6 = f1 * 3.1415927F +1.0F;
    	GlStateManager.translate(0, (-(float)(Math.sin(f6 + 1.0F)+ 0.5D)* 0.08F), 0);
    	this.Shape1.render(scale);
    	this.Shape2.render(scale);
    	this.Shape3.render(scale);
    	this.Shape4.render(scale);

    	this.Shape6.render(scale);
    	
    	GlStateManager.popMatrix();
    }
   }
    
  }}
  